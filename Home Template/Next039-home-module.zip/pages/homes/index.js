import React from "react";

function index() {
  return <h1>All Homes Page</h1>;
}

export default index;
