import React from "react";

function SingleHomeDetailsPage() {
  return <h1>SingleHome Details Page</h1>;
}

export default SingleHomeDetailsPage;
